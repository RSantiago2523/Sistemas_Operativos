#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>
#include <errno.h>

#define MAX_MESSAGE_SIZE 255
#define SERVER_KEY 1234

struct mensagem {
    long para;
    long de;
    char texto[MAX_MESSAGE_SIZE];
};

int msqid;

void handle_sigint(int sig) {
    // Termina o cliente
    printf("Cliente terminado.\n");
    exit(0);
}

int main() {
    printf("Cliente iniciado.\n");

    signal(SIGINT, handle_sigint);

    // Cria��o da fila de mensagens
    key_t msq_key = ftok("/tmp", SERVER_KEY);
    msqid = msgget(msq_key, IPC_CREAT | 0666);

    while (1) {
        char comando[MAX_MESSAGE_SIZE];

        printf("Digite um comando (ou 'exit' para sair): ");
        fgets(comando, MAX_MESSAGE_SIZE, stdin);

        // Remover a quebra de linha gerada pelo fgets
        comando[strcspn(comando, "\n")] = '\0';

        struct mensagem message;
        message.para = 1; // Envia para o servidor
        message.de = getpid();
        strcpy(message.texto, comando);

        if (msgsnd(msqid, &message, sizeof(message.texto), 0) == -1) {
            perror("Erro no envio de mensagem");
            handle_sigint(0);
        }

        if (strcmp(comando, "exit") == 0) {
            break;
        }

        // Processo para escuta de respostas do servidor
        if (msgrcv(msqid, &message, sizeof(message.texto), getpid(), 0) == -1) {
            perror("Erro ao ler mensagem");
            handle_sigint(0);
        }

        // Imprime a resposta do servidor
        if (strcmp(message.texto, "Livro n�o encontrado") == 0) {
            printf("%s\n", message.texto);
        } else {
            printf("Resposta do servidor: %s\n", message.texto);
        }
    }

    return 0;
}
