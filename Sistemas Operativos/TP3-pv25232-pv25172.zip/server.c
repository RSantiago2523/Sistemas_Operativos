#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>
#include <string.h>
#include <sys/wait.h>

#define MAX_MESSAGE_SIZE 255 //Tamanho m�ximo da mensagem
#define MAX_BOOKS 10 //N�mero m�ximo de livros na base de dados
#define SERVER_KEY 1234 //Chave para gerar a Chave IPC

struct mensagem {
    long para;
    long de;
    char texto[MAX_MESSAGE_SIZE];
};// Representa mensagens enviadas e recebidas pelo servidor

int msqid;//Identificador da Fila de Mensagens
int clientes_ativos = 0;//Representa o n�mero de clientes conectados ao servidor

struct livro {
    int codigo;
    char titulo[100];
    char autor[100];
    float preco;
};//Representa um livro

struct livro base_de_dados[MAX_BOOKS];//Estrutura da Base de Dados dos Livros
int total_livros = 0;//Contador do total de livros na Base de Dados

void handle_sigint(int sig) {
    // Elimina o mecanismo IPC utilizado
    msgctl(msqid, IPC_RMID, NULL);
    printf("Servidor terminado.\n");
    exit(0);
}

void handle_sigchld(int sig) {
    // Trata o sinal SIGCHLD para evitar processos zombies
    while (waitpid(-1, NULL, WNOHANG) > 0);
}

void carregar_base_de_dados() {
    printf("Digite os dados da base de dados (digite -1 no c�digo do livro para encerrar):\n");

    while (total_livros < MAX_BOOKS) {
        printf("C�digo do livro: ");
        scanf("%d", &base_de_dados[total_livros].codigo);

        // Verifica se deve encerrar a entrada de livros
        if (base_de_dados[total_livros].codigo == -1) {
            break;
        }

        printf("T�tulo: ");
        scanf("%s", base_de_dados[total_livros].titulo);

        printf("Autor: ");
        scanf("%s", base_de_dados[total_livros].autor);

        printf("Pre�o: ");
        scanf("%f", &base_de_dados[total_livros].preco);

        total_livros++;
    }

    printf("Base de dados criada com sucesso.\n");
}

void pesquisar_livro(struct mensagem *message) {
    int codigo_procurado;
    sscanf(message->texto, "%d", &codigo_procurado);

    for (int i = 0; i < total_livros; i++) {
        if (base_de_dados[i].codigo == codigo_procurado) {
            sprintf(message->texto, "Livro encontrado: %s, %s, %.2f", base_de_dados[i].titulo, base_de_dados[i].autor, base_de_dados[i].preco);
            return;
        }
    }

    strcpy(message->texto, "Livro n�o encontrado para o c�digo.");
}

int main() {
    printf("Servidor iniciado.\n");

    signal(SIGINT, handle_sigint);
    signal(SIGCHLD, handle_sigchld);

    // Cria��o da fila de mensagens
    key_t msq_key = ftok("/tmp", SERVER_KEY);
    msqid = msgget(msq_key, IPC_CREAT | 0666);

    // Carrega a base de dados a partir da entrada do utilizador
    carregar_base_de_dados();

    while (1) {
        // Aguarda mensagens na fila
        struct mensagem message;

        if (msgrcv(msqid, &message, sizeof(message.texto), 1, 0) != -1) {
            if (strcmp(message.texto, "exit") == 0) {
                clientes_ativos--;

                // Verifica se todos os clientes terminaram
                if (clientes_ativos == 0) {
                    handle_sigint(0); // Chama a fun��o de tratamento de sinal para encerrar o servidor
                }
            } else {
                pid_t pid = fork();

                if (pid == 0) {
                    // Processo filho
                    pesquisar_livro(&message);

                    // Envia resposta ao cliente
                    message.para = message.de; // Envia de volta para o cliente
                    message.de = 1;

                    if (msgsnd(msqid, &message, sizeof(message.texto), 0) == -1) {
                        perror("Erro no envio de mensagem");
                        handle_sigint(0); // Chama a fun��o de tratamento de sinal para encerrar em caso de erro no envio
                    }

                    exit(0);
                } else if (pid > 0) {
                    // Processo pai
                    clientes_ativos++;
                } else {
                    perror("Erro na cria��o do processo filho");
                    handle_sigint(0); // Chama a fun��o de tratamento de sinal para encerrar em caso de erro na cria��o do processo filho
                }
            }
        }

        // Aguarda um curto per�odo para evitar uso excessivo da CPU
        usleep(1000);
    }

    return 0;
}
