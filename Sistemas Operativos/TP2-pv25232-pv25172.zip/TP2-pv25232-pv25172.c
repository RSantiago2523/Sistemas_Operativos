#include <stdio.h> //padr�o
#include <stdlib.h> //padr�o
#include <unistd.h> //para forks , pids, execlp, exit e fprintf
#include <sys/types.h> //para o pid_t
#include <sys/wait.h> //para o waitpid
#include <locale.h>// Portugu�s

int main(int argc, char *argv[]) {

    int num_comandos;

    if (argc < 2) { // o valor m�nimo � sempre 1 porque o pr�prio programa � um argumento
        fprintf(stdout, "Uso: %s <comando1> <comando2> ... <comandoX>\n", argv[0]);
        exit(1);
    }

    num_comandos = argc - 1; // o nome do programa conta como argumento ent�o fazemos -1, o n�mero de comandos � uma vari�vel que armazena o n�mero de
                             // argumentos.

    printf("LISTA DE ARGUMENTOS:\n"); //lista de argumentos = n�mero de comandos
    for (int i = 1; i <= num_comandos; i++) {
        printf("%d. %s\n", i, argv[i]);//printf ao n�mero do argumento, o argumento e \n para par�grafo
    }

    //por cada argumento criar um filho com fork(), o n�mero de filhos(fork()) = n�mero de argumentos
    for (int i = 1; i <= num_comandos; i++) {
        pid_t pid = fork();

        if (pid == -1) {
            perror("Erro ao criar processo filho");
            exit(1);
        } else if (pid == 0) {
            // C�digo do processo filho
            printf("\nA processar filho com PID=%d & PID PAI=%d...\n", getpid(), getppid());
            if (execlp(argv[i], argv[i], NULL) == -1) { // execlp executa os argumentos
                fprintf(stdout, "\nO comando %s nao foi concluido com sucesso\n", argv[i]);
                exit(1);
            }
        }
  }

    // O Processo pai vai aguardar a conclus�o de cada processo filho
    int num_completos = 0; // n�mero de processos filhos que foram completados com sucesso
    while (num_completos < num_comandos) {
        int status;
        pid_t child_pid = waitpid(-1, &status, 0); //waitpid espera pelos processos,o status armazena a sa�da do processo filho, o 0 bloqueia o processo pai at� que os filhos terminem.

        if (child_pid == -1) { //-1 indica que o processo falhou ou ocorreu um erro
            perror("Erro ao esperar pelo processo filho");
            exit(1);
        }

        if (status == 0) {
        printf("\nProcesso filho %d terminou com sucesso\n", child_pid); // O valor zero em status indica que o processo filho terminou normalmente.
    	} 
	else {
        fprintf(stderr, "\nProcesso filho %d terminou mal ou com c�digo de sa�da diferente de zero\n", child_pid); // Um valor diferente de zero em status indica que o processo filho terminou com um c�digo de sa�da diferente de zero.
	}

        num_completos++;
    }

    printf("\nTUDO TERMINADO, FIM!\n");

    return 0;
}
